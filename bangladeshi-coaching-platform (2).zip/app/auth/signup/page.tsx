"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, EyeOff, ArrowRight, BookOpen, CheckCircle2, Sparkles, Trophy, Star } from "lucide-react"

export default function SignupPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [studentClass, setStudentClass] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      setShowSuccess(true)
      // Auto redirect after success animation
      setTimeout(() => {
        // Redirect to login or dashboard
        window.location.href = "/auth/login"
      }, 3000)
    }, 1500)
  }

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center px-4">
        <div className="text-center animate-in zoom-in duration-700">
          {/* Success Animation Container */}
          <div className="relative mb-8">
            {/* Celebration Particles */}
            <div className="absolute inset-0 pointer-events-none">
              {[...Array(12)].map((_, i) => (
                <div
                  key={i}
                  className="absolute animate-bounce"
                  style={{
                    left: `${20 + ((i * 60) % 80)}%`,
                    top: `${10 + ((i * 30) % 60)}%`,
                    animationDelay: `${i * 0.1}s`,
                    animationDuration: `${1 + (i % 3) * 0.5}s`,
                  }}
                >
                  {i % 3 === 0 ? (
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                  ) : i % 3 === 1 ? (
                    <Star className="w-3 h-3 text-blue-400" />
                  ) : (
                    <div className="w-2 h-2 bg-purple-400 rounded-full" />
                  )}
                </div>
              ))}
            </div>

            {/* Main Success Icon */}
            <div className="relative mx-auto w-32 h-32 mb-6">
              <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse"></div>
              <div className="absolute inset-2 bg-white rounded-full flex items-center justify-center animate-in zoom-in duration-500 delay-300">
                <CheckCircle2 className="w-16 h-16 text-green-500 animate-in zoom-in duration-300 delay-500" />
              </div>

              {/* Ripple Effect */}
              <div className="absolute inset-0 border-4 border-green-400 rounded-full animate-ping opacity-75"></div>
              <div
                className="absolute inset-0 border-4 border-emerald-400 rounded-full animate-ping opacity-50"
                style={{ animationDelay: "0.5s" }}
              ></div>
            </div>

            {/* Trophy Icon */}
            <div className="absolute -top-4 -right-4 animate-in slide-in-from-top duration-700 delay-700">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg animate-bounce">
                <Trophy className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          {/* Success Message */}
          <div className="animate-in fade-in duration-700 delay-400">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Welcome to StudyBD! 🎉
            </h1>
            <p className="text-xl text-gray-600 mb-6 max-w-md mx-auto">
              Your account has been created successfully. Get ready to start your amazing learning journey!
            </p>

            {/* Success Stats */}
            <div className="flex items-center justify-center space-x-8 mb-8 animate-in slide-in-from-bottom duration-700 delay-600">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">✓</div>
                <div className="text-sm text-gray-600">Account Created</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">📚</div>
                <div className="text-sm text-gray-600">Courses Ready</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">🚀</div>
                <div className="text-sm text-gray-600">Ready to Learn</div>
              </div>
            </div>

            {/* Redirect Message */}
            <div className="animate-in fade-in duration-500 delay-1000">
              <p className="text-gray-500 mb-4">Redirecting you to login page...</p>
              <div className="w-48 h-2 bg-gray-200 rounded-full mx-auto overflow-hidden">
                <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full animate-progress"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex flex-col animate-in fade-in duration-700">
      {/* Navigation */}
      <nav className="w-full glassmorphism z-50 border-b border-white/20">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="text-2xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              StudyBD
            </div>
          </Link>
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">
              Home
            </Link>
            <Link href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">
              Courses
            </Link>
            <Link href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">
              About
            </Link>
            <Button
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-6 py-2 rounded-2xl font-semibold transform hover:scale-105 transition-all duration-300 shadow-lg"
              asChild
            >
              <Link href="/auth/login">Join Free</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="flex-1 container mx-auto px-4 py-12 flex flex-col md:flex-row items-center justify-center md:justify-between">
        {/* Left Side - Signup Form */}
        <div className="w-full md:w-1/2 max-w-md order-2 md:order-1 animate-in slide-in-from-left duration-700 delay-300">
          <div className="glassmorphism rounded-3xl p-8 shadow-xl border border-white/20 transform hover:scale-[1.02] transition-all duration-300">
            <div className="flex items-center justify-center mb-6 animate-in zoom-in duration-500 delay-100">
              <div className="w-12 h-12 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg transform hover:scale-110 transition-all duration-300 hover:rotate-12">
                <BookOpen className="text-white w-6 h-6" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-center mb-2 text-gray-800">Create Your Free Account</h2>
            <p className="text-gray-600 text-center mb-6">Join Bangladesh's most trusted online coaching platform</p>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2 animate-in slide-in-from-bottom duration-500 delay-100">
                <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">
                  Full Name
                </label>
                <Input
                  id="fullName"
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 hover:border-purple-300 focus:scale-[1.02]"
                  required
                />
              </div>

              <div className="space-y-2 animate-in slide-in-from-bottom duration-500 delay-200">
                <label htmlFor="studentClass" className="block text-sm font-medium text-gray-700">
                  Class
                </label>
                <div className="relative">
                  <Select value={studentClass} onValueChange={setStudentClass}>
                    <SelectTrigger
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-white text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 hover:border-indigo-300 focus:scale-[1.02]"
                      aria-label="Select your class"
                    >
                      <SelectValue placeholder="Select your class" />
                    </SelectTrigger>
                    <SelectContent
                      className="bg-white border border-gray-200 rounded-xl shadow-lg z-50 animate-in fade-in slide-in-from-top duration-200"
                      position="popper"
                      sideOffset={5}
                    >
                      <SelectItem value="class6" className="py-2.5 hover:bg-indigo-50 transition-colors duration-150">
                        Class 6
                      </SelectItem>
                      <SelectItem value="class7" className="py-2.5 hover:bg-indigo-50 transition-colors duration-150">
                        Class 7
                      </SelectItem>
                      <SelectItem value="class8" className="py-2.5 hover:bg-indigo-50 transition-colors duration-150">
                        Class 8
                      </SelectItem>
                      <SelectItem value="class9" className="py-2.5 hover:bg-indigo-50 transition-colors duration-150">
                        Class 9
                      </SelectItem>
                      <SelectItem value="class10" className="py-2.5 hover:bg-indigo-50 transition-colors duration-150">
                        Class 10
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2 animate-in slide-in-from-bottom duration-500 delay-300">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email or Phone
                </label>
                <Input
                  id="email"
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email or phone"
                  className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 hover:border-purple-300 focus:scale-[1.02]"
                  required
                />
              </div>

              <div className="space-y-2 animate-in slide-in-from-bottom duration-500 delay-400">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Create a strong password"
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 hover:border-purple-300 focus:scale-[1.02]"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-all duration-200 hover:scale-110"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2 animate-in slide-in-from-bottom duration-500 delay-500">
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                  Confirm Password
                </label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm your password"
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 hover:border-purple-300 focus:scale-[1.02]"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-all duration-200 hover:scale-110"
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-4 pt-2 animate-in slide-in-from-bottom duration-500 delay-600">
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white py-3 rounded-xl font-semibold transform hover:scale-[1.02] transition-all duration-300 shadow-lg flex items-center justify-center hover:shadow-xl hover:shadow-purple-500/25 group"
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      <span>Creating Account...</span>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <span>Sign Up Now</span>
                      <ArrowRight className="ml-2 w-5 h-5 transition-transform duration-200 group-hover:translate-x-1" />
                    </div>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  By signing up, you agree to our{" "}
                  <Link href="#" className="text-purple-600 hover:underline">
                    Terms of Service
                  </Link>{" "}
                  and{" "}
                  <Link href="#" className="text-purple-600 hover:underline">
                    Privacy Policy
                  </Link>
                </p>
              </div>
            </form>

            <div className="mt-8 text-center">
              <p className="text-gray-600">
                Already have an account?{" "}
                <Link
                  href="/auth/login"
                  className="text-purple-600 hover:text-purple-800 font-medium hover:underline transition-colors"
                >
                  Log In
                </Link>
              </p>
            </div>
          </div>
        </div>

        {/* Right Side - Illustration */}
        <div className="w-full md:w-1/2 mb-10 md:mb-0 flex flex-col items-center md:items-end order-1 md:order-2 animate-in slide-in-from-right duration-700 delay-200">
          <div className="max-w-md">
            <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800 text-center md:text-right animate-in fade-in duration-700 delay-400">
              Join{" "}
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                StudyBD
              </span>{" "}
              Today!
            </h1>
            <p className="text-lg text-gray-600 mb-8 text-center md:text-right animate-in fade-in duration-700 delay-500">
              Start your learning journey with Bangladesh's top online coaching platform.
            </p>

            <div className="relative w-full max-w-md h-64 md:h-80 animate-in zoom-in duration-700 delay-600">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Students learning"
                fill
                className="object-contain"
              />
            </div>

            <div className="mt-8 space-y-4 hidden md:block">
              <div className="flex items-start space-x-3 animate-in slide-in-from-right duration-500 delay-700">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700">Access to expert teachers from top coaching centers</p>
              </div>
              <div className="flex items-start space-x-3 animate-in slide-in-from-right duration-500 delay-800">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700">Interactive live classes and recorded sessions</p>
              </div>
              <div className="flex items-start space-x-3 animate-in slide-in-from-right duration-500 delay-900">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700">Practice tests and personalized feedback</p>
              </div>
            </div>
          </div>

          {/* Floating Elements */}
          <div className="absolute top-1/3 right-1/4 w-16 h-16 bg-gradient-to-r from-indigo-400 to-purple-400 rounded-full opacity-20 animate-float hidden md:block"></div>
          <div className="absolute bottom-1/4 left-1/3 w-24 h-24 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-20 animate-float-delayed hidden md:block"></div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-6 border-t border-gray-200 bg-white/50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mr-2">
                StudyBD
              </div>
              <span className="text-sm text-gray-500">© {new Date().getFullYear()} All rights reserved</span>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="#" className="text-gray-600 hover:text-gray-900 transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="text-gray-600 hover:text-gray-900 transition-colors">
                Terms of Service
              </Link>
              <Link href="#" className="text-gray-600 hover:text-gray-900 transition-colors">
                Help Center
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
