"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  ChevronLeft,
  ChevronRight,
  Star,
  Facebook,
  Youtube,
  Menu,
  X,
  Play,
  Users,
  BookOpen,
  Award,
  Quote,
  Heart,
  Zap,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function LandingPage() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [animatedElements, setAnimatedElements] = useState(new Set())

  const observerRef = useRef<IntersectionObserver | null>(null)

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  }

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setAnimatedElements((prev) => new Set(prev).add(entry.target.id))
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = document.querySelectorAll(".scroll-animate")
    elements.forEach((el) => {
      if (observerRef.current) {
        observerRef.current.observe(el)
      }
    })

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect()
      }
    }
  }, [])

  const testimonials = [
    {
      text: "StudyBD helped me improve my SSC preparation significantly! The teachers explain everything in Bangla which makes it so easy to understand.",
      name: "Mim Rahman",
      class: "Class 10",
      rating: 5,
      avatar: "/placeholder.svg?height=80&width=80",
      improvement: "+2 Grades",
      subject: "Mathematics",
      gradient: "from-pink-500 to-rose-500",
      bgPattern: "🌟",
    },
    {
      text: "Best online coaching platform in Bangladesh! My grades improved from C to A+ after joining their classes.",
      name: "Rafiq Ahmed",
      class: "Class 9",
      rating: 5,
      avatar: "/placeholder.svg?height=80&width=80",
      improvement: "C to A+",
      subject: "Physics",
      gradient: "from-blue-500 to-cyan-500",
      bgPattern: "⚡",
    },
    {
      text: "The interactive classes and friendly teachers make learning fun. I never thought online coaching could be this effective!",
      name: "Fatema Khatun",
      class: "Class 8",
      rating: 5,
      avatar: "/placeholder.svg?height=80&width=80",
      improvement: "+85% Score",
      subject: "English",
      gradient: "from-purple-500 to-indigo-500",
      bgPattern: "🚀",
    },
    {
      text: "Amazing platform! The live classes feel just like being in a real classroom. My confidence has increased so much!",
      name: "Karim Hassan",
      class: "Class 7",
      rating: 5,
      avatar: "/placeholder.svg?height=80&width=80",
      improvement: "+3 Grades",
      subject: "Science",
      gradient: "from-green-500 to-emerald-500",
      bgPattern: "💡",
    },
  ]

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  // Auto-advance testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      nextTestimonial()
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-yellow-50 overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full glassmorphism z-50 border-b border-white/20">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-yellow-500 bg-clip-text text-transparent">
            StudyBD
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="#courses" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">
              Courses
            </Link>
            <Link href="#about" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">
              About
            </Link>
            <Link href="#contact" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">
              Contact
            </Link>
            <Button
              className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white px-6 py-2 rounded-2xl font-semibold transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              asChild
            >
              <Link href="/auth/login">Join Free</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-xl bg-white/20 backdrop-blur-sm"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden glassmorphism border-t border-white/20">
            <div className="px-4 py-4 space-y-3">
              <Link href="#courses" className="block py-2 text-gray-700 hover:text-purple-600 font-medium">
                Courses
              </Link>
              <Link href="#about" className="block py-2 text-gray-700 hover:text-purple-600 font-medium">
                About
              </Link>
              <Link href="#contact" className="block py-2 text-gray-700 hover:text-purple-600 font-medium">
                Contact
              </Link>
              <Button
                className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white rounded-2xl font-semibold transform hover:scale-105 transition-all duration-300 shadow-lg"
                asChild
              >
                <Link href="/auth/login">Join Free</Link>
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-28 pb-20 px-4 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-20 animate-float"></div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full opacity-20 animate-float-delayed"></div>
        <div className="absolute bottom-20 left-1/4 w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full opacity-20 animate-float"></div>

        <div className="container mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div
              className={`text-center lg:text-left space-y-8 scroll-animate ${animatedElements.has("hero-content") ? "animate" : ""}`}
              id="hero-content"
            >
              <div className="space-y-6">
                <div className="inline-block px-6 py-3 bg-gradient-to-r from-purple-100 to-blue-100 rounded-3xl text-purple-700 font-semibold text-sm border border-purple-200">
                  🎓 Bangladesh's #1 Online Coaching Platform
                </div>
                <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight">
                  Your Digital Coaching for{" "}
                  <span className="bg-gradient-to-r from-purple-600 via-blue-600 to-yellow-500 bg-clip-text text-transparent">
                    Class 6–10
                  </span>
                </h1>
                <p className="text-xl md:text-2xl text-gray-600 max-w-2xl font-medium">
                  Top coaching classes for Bangladeshi students, all in one place.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button
                  size="lg"
                  onClick={() => scrollToSection("courses")}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-10 py-4 rounded-3xl text-lg font-bold transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-purple-500/25"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Browse Classes
                </Button>
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-10 py-4 rounded-3xl text-lg font-bold transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-green-500/25"
                  asChild
                >
                  <Link href="/auth/login">Join Free</Link>
                </Button>
              </div>

              <div className="flex items-center justify-center lg:justify-start space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">10K+</div>
                  <div className="text-sm text-gray-600">Students</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">50+</div>
                  <div className="text-sm text-gray-600">Teachers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-600">95%</div>
                  <div className="text-sm text-gray-600">Success Rate</div>
                </div>
              </div>
            </div>

            <div
              className={`relative scroll-animate ${animatedElements.has("hero-image") ? "animate" : ""}`}
              id="hero-image"
            >
              <div className="relative z-10 transform hover:scale-105 transition-transform duration-500">
                <div className="gradient-border">
                  <div className="gradient-border-inner p-4">
                    <Image
                      src="/placeholder.svg?height=500&width=600"
                      alt="Students learning online"
                      width={600}
                      height={500}
                      className="rounded-2xl relative z-10"
                    />
                  </div>
                </div>
              </div>

              {/* Floating Stats */}
              <div className="absolute -top-6 -right-6 glassmorphism rounded-3xl p-4 animate-float z-20 shadow-xl">
                <div className="flex items-center space-x-2">
                  <Users className="w-6 h-6 text-purple-600" />
                  <div>
                    <div className="text-sm font-bold text-gray-800">Live Now</div>
                    <div className="text-xs text-gray-600">2.5K Students</div>
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-6 -left-6 glassmorphism rounded-3xl p-4 animate-float-delayed z-20 shadow-xl">
                <div className="flex items-center space-x-2">
                  <Award className="w-6 h-6 text-yellow-600" />
                  <div>
                    <div className="text-sm font-bold text-gray-800">Top Rated</div>
                    <div className="text-xs text-gray-600">4.9/5 Stars</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div
            className={`text-center mb-16 scroll-animate ${animatedElements.has("features-header") ? "animate" : ""}`}
            id="features-header"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Why Students{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Love Us
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-medium">
              Join thousands of students who are already improving their grades with our innovative platform
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: "🎯",
                title: "Class-Wise Coaching",
                subtitle: "from Verified Teachers",
                gradient: "from-purple-500 via-purple-600 to-pink-600",
                delay: "0s",
              },
              {
                icon: "📚",
                title: "NCTB Curriculum",
                subtitle: "Covered",
                gradient: "from-blue-500 via-blue-600 to-cyan-600",
                delay: "0.2s",
              },
              {
                icon: "🇧🇩",
                title: "100% Bangla-Friendly",
                subtitle: "Interface",
                gradient: "from-green-500 via-green-600 to-emerald-600",
                delay: "0.4s",
              },
              {
                icon: "💻",
                title: "Join Anytime",
                subtitle: "Learn Anywhere",
                gradient: "from-yellow-500 via-orange-500 to-red-500",
                delay: "0.6s",
              },
            ].map((item, index) => (
              <div
                key={index}
                className={`scroll-animate ${animatedElements.has(`feature-${index}`) ? "animate" : ""}`}
                id={`feature-${index}`}
                style={{ animationDelay: item.delay }}
              >
                <Card className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4 hover:scale-105 border-0 rounded-3xl overflow-hidden bg-gradient-to-br from-white to-gray-50 shadow-xl">
                  <CardContent className="p-8 text-center relative">
                    <div
                      className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500 rounded-3xl`}
                    ></div>
                    <div className="relative z-10">
                      <div className="text-5xl mb-6 transform group-hover:scale-125 group-hover:rotate-12 transition-all duration-500">
                        {item.icon}
                      </div>
                      <h3 className="font-bold text-xl mb-3 text-gray-800">{item.title}</h3>
                      <p
                        className={`text-sm bg-gradient-to-r ${item.gradient} bg-clip-text text-transparent font-semibold`}
                      >
                        {item.subtitle}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-20 px-4 bg-gradient-to-br from-purple-50 to-blue-50 relative">
        <div className="container mx-auto">
          <div
            className={`text-center mb-16 scroll-animate ${animatedElements.has("courses-header") ? "animate" : ""}`}
            id="courses-header"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Choose Your{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">Class</span>
            </h2>
            <p className="text-xl text-gray-600 font-medium">
              Select your class and start learning with expert teachers
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {[
              {
                class: "Class 6",
                gradient: "from-purple-400 via-purple-500 to-purple-600",
                subjects: "Math, Science, English",
                description: "Explore best coaching options for Class 6",
                students: "2.1K",
                route: "/courses/class-6",
              },
              {
                class: "Class 7",
                gradient: "from-pink-400 via-pink-500 to-pink-600",
                subjects: "Math, Science, English",
                description: "Comprehensive learning for Class 7",
                students: "1.8K",
                route: "/courses/class-7",
              },
              {
                class: "Class 8",
                gradient: "from-blue-400 via-blue-500 to-blue-600",
                subjects: "Math, Science, English",
                description: "Advanced concepts for Class 8",
                students: "2.3K",
                route: "/courses/class-8",
              },
              {
                class: "Class 9",
                gradient: "from-green-400 via-green-500 to-green-600",
                subjects: "Physics, Chemistry, Math",
                description: "SSC preparation starts here",
                students: "3.2K",
                route: "/courses/class-9",
              },
              {
                class: "Class 10",
                gradient: "from-yellow-400 via-orange-500 to-red-500",
                subjects: "SSC Preparation",
                description: "Complete SSC exam preparation",
                students: "4.1K",
                route: "/courses/class-10",
              },
            ].map((item, index) => (
              <div
                key={index}
                className={`scroll-animate ${animatedElements.has(`course-${index}`) ? "animate" : ""}`}
                id={`course-${index}`}
              >
                <Card className="group cursor-pointer hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-6 hover:scale-105 border-0 rounded-3xl overflow-hidden glassmorphism">
                  <div className={`h-40 bg-gradient-to-br ${item.gradient} relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-all duration-500"></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 text-white">
                      <h3 className="text-2xl font-bold">{item.class}</h3>
                      <div className="flex items-center space-x-1 mt-1">
                        <Users className="w-4 h-4" />
                        <span className="text-sm">{item.students} students</span>
                      </div>
                    </div>
                    <div className="absolute top-4 right-4">
                      <BookOpen className="w-6 h-6 text-white/80" />
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-3 font-medium">{item.subjects}</p>
                    <p className="text-xs text-gray-500 mb-4">{item.description}</p>
                    <Link href={item.route}>
                      <Button
                        size="sm"
                        className={`w-full bg-gradient-to-r ${item.gradient} hover:opacity-90 text-white border-0 transform group-hover:scale-105 transition-all duration-300 rounded-2xl font-semibold shadow-lg hover:shadow-xl hover:shadow-${item.gradient.split("-")[1]}-500/25`}
                      >
                        Explore Courses
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Testimonials Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 text-6xl animate-float">⭐</div>
          <div className="absolute top-20 right-20 text-4xl animate-float-delayed">🚀</div>
          <div className="absolute bottom-20 left-20 text-5xl animate-float">💡</div>
          <div className="absolute bottom-10 right-10 text-3xl animate-float-delayed">🎯</div>
        </div>

        <div className="container mx-auto relative z-10">
          <div
            className={`text-center mb-16 scroll-animate ${animatedElements.has("testimonials-header") ? "animate" : ""}`}
            id="testimonials-header"
          >
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-6 py-3 mb-6">
              <Heart className="w-5 h-5 text-pink-400" />
              <span className="text-white font-medium">Student Success Stories</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
              What Our{" "}
              <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-blue-400 bg-clip-text text-transparent">
                Students Say
              </span>
            </h2>
            <p className="text-xl text-gray-300 font-medium">Real feedback from real students achieving real results</p>
          </div>

          <div
            className={`max-w-6xl mx-auto scroll-animate ${animatedElements.has("testimonials-content") ? "animate" : ""}`}
            id="testimonials-content"
          >
            {/* Main Testimonial Card */}
            <div className="relative">
              <div className="glassmorphism rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 bg-white/5 backdrop-blur-xl">
                {/* Background Pattern for Current Testimonial */}
                <div className="absolute top-4 right-4 text-6xl opacity-20">
                  {testimonials[currentTestimonial].bgPattern}
                </div>

                <div className="grid md:grid-cols-3 gap-8 items-center">
                  {/* Left: Student Info */}
                  <div className="text-center md:text-left">
                    <div className="relative inline-block mb-4">
                      <div
                        className={`absolute inset-0 bg-gradient-to-r ${testimonials[currentTestimonial].gradient} rounded-full animate-pulse`}
                      ></div>
                      <div className="relative bg-white rounded-full p-1">
                        <Image
                          src={testimonials[currentTestimonial].avatar || "/placeholder.svg"}
                          alt={testimonials[currentTestimonial].name}
                          width={80}
                          height={80}
                          className="rounded-full"
                        />
                      </div>
                      {/* Achievement Badge */}
                      <div className="absolute -bottom-2 -right-2 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full p-2 shadow-lg">
                        <Zap className="w-4 h-4 text-white" />
                      </div>
                    </div>
                    <h3 className="font-bold text-xl text-white mb-1">{testimonials[currentTestimonial].name}</h3>
                    <p
                      className={`bg-gradient-to-r ${testimonials[currentTestimonial].gradient} bg-clip-text text-transparent font-semibold mb-2`}
                    >
                      {testimonials[currentTestimonial].class}
                    </p>
                    <div className="space-y-2">
                      <div className="inline-flex items-center space-x-2 bg-white/10 rounded-full px-3 py-1">
                        <span className="text-sm text-gray-300">{testimonials[currentTestimonial].subject}</span>
                      </div>
                      <div
                        className={`inline-flex items-center space-x-2 bg-gradient-to-r ${testimonials[currentTestimonial].gradient} rounded-full px-3 py-1 ml-2`}
                      >
                        <span className="text-sm text-white font-bold">
                          {testimonials[currentTestimonial].improvement}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Center: Testimonial Content */}
                  <div className="md:col-span-2">
                    <div className="relative">
                      <Quote className="absolute -top-4 -left-4 w-8 h-8 text-purple-400 opacity-50" />
                      <blockquote className="text-xl md:text-2xl text-white mb-6 italic font-medium leading-relaxed pl-8">
                        "{testimonials[currentTestimonial].text}"
                      </blockquote>
                    </div>

                    {/* Rating Stars */}
                    <div className="flex items-center space-x-1 mb-4">
                      {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-6 h-6 text-yellow-400 fill-current animate-pulse"
                          style={{ animationDelay: `${i * 0.1}s` }}
                        />
                      ))}
                      <span className="ml-2 text-gray-300 font-medium">Perfect Score!</span>
                    </div>

                    {/* Achievement Metrics */}
                    <div className="grid grid-cols-3 gap-4 mt-6">
                      <div className="text-center bg-white/10 rounded-xl p-3">
                        <div className="text-2xl font-bold text-white">98%</div>
                        <div className="text-xs text-gray-300">Attendance</div>
                      </div>
                      <div className="text-center bg-white/10 rounded-xl p-3">
                        <div className="text-2xl font-bold text-white">A+</div>
                        <div className="text-xs text-gray-300">Current Grade</div>
                      </div>
                      <div className="text-center bg-white/10 rounded-xl p-3">
                        <div className="text-2xl font-bold text-white">6mo</div>
                        <div className="text-xs text-gray-300">With StudyBD</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Navigation Buttons */}
              <button
                onClick={prevTestimonial}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 p-4 rounded-2xl glassmorphism hover:shadow-xl transition-all duration-300 hover:scale-110 bg-white/10 backdrop-blur-sm group"
              >
                <ChevronLeft className="w-6 h-6 text-white group-hover:text-purple-400 transition-colors" />
              </button>
              <button
                onClick={nextTestimonial}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 p-4 rounded-2xl glassmorphism hover:shadow-xl transition-all duration-300 hover:scale-110 bg-white/10 backdrop-blur-sm group"
              >
                <ChevronRight className="w-6 h-6 text-white group-hover:text-purple-400 transition-colors" />
              </button>
            </div>

            {/* Testimonial Indicators */}
            <div className="flex justify-center mt-8 space-x-3">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`relative overflow-hidden rounded-full transition-all duration-300 ${
                    index === currentTestimonial ? "w-12 h-4" : "w-4 h-4 hover:w-6"
                  }`}
                >
                  <div
                    className={`absolute inset-0 bg-gradient-to-r ${testimonials[index].gradient} ${
                      index === currentTestimonial ? "opacity-100" : "opacity-50 hover:opacity-75"
                    } transition-opacity duration-300`}
                  ></div>
                </button>
              ))}
            </div>

            {/* Mini Testimonials Preview */}
            <div className="grid md:grid-cols-3 gap-4 mt-12">
              {testimonials
                .filter((_, index) => index !== currentTestimonial)
                .slice(0, 3)
                .map((testimonial, index) => (
                  <div
                    key={index}
                    className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10 hover:bg-white/10 transition-all duration-300 cursor-pointer"
                    onClick={() => setCurrentTestimonial(testimonials.indexOf(testimonial))}
                  >
                    <div className="flex items-center space-x-3 mb-3">
                      <Image
                        src={testimonial.avatar || "/placeholder.svg"}
                        alt={testimonial.name}
                        width={40}
                        height={40}
                        className="rounded-full"
                      />
                      <div>
                        <p className="text-white font-medium text-sm">{testimonial.name}</p>
                        <p className="text-gray-400 text-xs">{testimonial.class}</p>
                      </div>
                    </div>
                    <p className="text-gray-300 text-sm line-clamp-2">{testimonial.text}</p>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 px-4 bg-gradient-to-r from-purple-600 via-blue-600 to-purple-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>

        {/* Background Shapes */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full animate-float"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-white/10 rounded-full animate-float-delayed"></div>
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-white/10 rounded-full animate-float"></div>

        <div className="container mx-auto relative z-10">
          <div
            className={`text-center text-white scroll-animate ${animatedElements.has("final-cta") ? "animate" : ""}`}
            id="final-cta"
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-8">Start Learning Smarter Today</h2>
            <p className="text-xl md:text-2xl mb-12 opacity-90 max-w-3xl mx-auto font-medium">
              Join thousands of students who are already improving their grades. Start your journey with us today!
            </p>
            <Button
              size="lg"
              onClick={() => scrollToSection("courses")}
              className="bg-white text-purple-600 hover:bg-gray-100 px-12 py-6 rounded-3xl text-xl font-bold transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-white/25"
            >
              <Play className="w-6 h-6 mr-3" />
              Explore Classes
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 text-white py-16 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent mb-6">
                StudyBD
              </div>
              <p className="text-gray-300 mb-6 max-w-md font-medium leading-relaxed">
                Bangladesh's leading online coaching platform for Class 6-10 students. Learn from verified teachers with
                our comprehensive NCTB syllabus-based courses.
              </p>
              <div className="flex space-x-4">
                <Link
                  href="#"
                  className="p-3 bg-blue-600 rounded-2xl hover:bg-blue-700 transition-colors transform hover:scale-110 duration-300"
                >
                  <Facebook className="w-6 h-6" />
                </Link>
                <Link
                  href="#"
                  className="p-3 bg-red-600 rounded-2xl hover:bg-red-700 transition-colors transform hover:scale-110 duration-300"
                >
                  <Youtube className="w-6 h-6" />
                </Link>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-6">Quick Links</h3>
              <ul className="space-y-3 text-gray-300">
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Our Teachers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Success Stories
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-6">Support</h3>
              <ul className="space-y-3 text-gray-300">
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Refund Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center text-gray-300">
            <p className="font-medium">
              &copy; {new Date().getFullYear()} StudyBD. All rights reserved. Made with ❤️ for Bangladeshi students.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
