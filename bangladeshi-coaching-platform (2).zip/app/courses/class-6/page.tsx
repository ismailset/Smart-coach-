"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, Clock, Users, Star, Filter, Facebook, Youtube, BookOpen, Play } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function Class6CoursesPage() {
  const [selectedSubject, setSelectedSubject] = useState("All")
  const [selectedType, setSelectedType] = useState("All")
  const [animatedElements, setAnimatedElements] = useState(new Set())

  const observerRef = useRef<IntersectionObserver | null>(null)

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setAnimatedElements((prev) => new Set(prev).add(entry.target.id))
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = document.querySelectorAll(".scroll-animate")
    elements.forEach((el) => {
      if (observerRef.current) {
        observerRef.current.observe(el)
      }
    })

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect()
      }
    }
  }, [])

  const courses = [
    {
      id: 1,
      title: "Mathematics - Full Syllabus",
      instructor: "Md. Rahman Khan",
      duration: "3 Months",
      batchInfo: "Weekly Live Classes",
      price: "৳2,500",
      type: "Paid",
      subject: "Mathematics",
      rating: 4.9,
      students: 1250,
      gradient: "from-blue-500 to-indigo-600",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      title: "English Grammar & Literature",
      instructor: "Fatema Begum",
      duration: "2 Months",
      batchInfo: "Bi-weekly Sessions",
      price: "Free",
      type: "Free",
      subject: "English",
      rating: 4.8,
      students: 980,
      gradient: "from-green-500 to-emerald-600",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 3,
      title: "General Science Fundamentals",
      instructor: "Dr. Karim Ahmed",
      duration: "4 Months",
      batchInfo: "Daily Practice Sessions",
      price: "৳3,000",
      type: "Paid",
      subject: "Science",
      rating: 4.9,
      students: 1450,
      gradient: "from-purple-500 to-pink-600",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 4,
      title: "Bangla Sahitya O Byakaron",
      instructor: "Rashida Khatun",
      duration: "3 Months",
      batchInfo: "Weekly Live Classes",
      price: "৳2,200",
      type: "Paid",
      subject: "Bangla",
      rating: 4.7,
      students: 890,
      gradient: "from-amber-500 to-orange-600",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 5,
      title: "Islamic Studies Complete",
      instructor: "Maulana Hafez Ali",
      duration: "2 Months",
      batchInfo: "Weekend Classes",
      price: "Free",
      type: "Free",
      subject: "Islamic Studies",
      rating: 4.8,
      students: 750,
      gradient: "from-teal-500 to-cyan-600",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 6,
      title: "Social Studies & Geography",
      instructor: "Nasir Uddin",
      duration: "3 Months",
      batchInfo: "Interactive Sessions",
      price: "৳2,800",
      type: "Paid",
      subject: "Social Studies",
      rating: 4.6,
      students: 650,
      gradient: "from-rose-500 to-red-600",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 7,
      title: "Art & Craft Creative Course",
      instructor: "Salma Akter",
      duration: "1 Month",
      batchInfo: "Hands-on Workshops",
      price: "৳1,500",
      type: "Paid",
      subject: "Art",
      rating: 4.5,
      students: 420,
      gradient: "from-violet-500 to-purple-600",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 8,
      title: "Physical Education & Health",
      instructor: "Rafiq Hassan",
      duration: "2 Months",
      batchInfo: "Practical Sessions",
      price: "Free",
      type: "Free",
      subject: "Physical Education",
      rating: 4.4,
      students: 380,
      gradient: "from-lime-500 to-green-600",
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  const subjects = [
    "All",
    "Mathematics",
    "English",
    "Science",
    "Bangla",
    "Islamic Studies",
    "Social Studies",
    "Art",
    "Physical Education",
  ]

  const filteredCourses = courses.filter((course) => {
    const subjectMatch = selectedSubject === "All" || course.subject === selectedSubject
    const typeMatch = selectedType === "All" || course.type === selectedType
    return subjectMatch && typeMatch
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Navigation */}
      <nav className="fixed top-0 w-full glassmorphism z-50 border-b border-white/20">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
            StudyBD
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              Home
            </Link>
            <Link href="#" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              About
            </Link>
            <Link href="#" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              Contact
            </Link>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-6 py-2 rounded-2xl font-semibold transform hover:scale-105 transition-all duration-300 shadow-lg">
              Join Free
            </Button>
          </div>
        </div>
      </nav>

      {/* Title Section */}
      <section className="pt-28 pb-12 px-4">
        <div className="container mx-auto">
          <div
            className={`scroll-animate ${animatedElements.has("title-section") ? "animate" : ""}`}
            id="title-section"
          >
            <Link
              href="/"
              className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium mb-6 transition-colors group"
            >
              <ArrowLeft className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform" />
              <span>Back to Home</span>
            </Link>

            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Class 6
                </span>{" "}
                Courses
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 font-medium max-w-3xl mx-auto">
                Learn from verified Bangladeshi coaching teachers, following the NCTB syllabus.
              </p>

              {/* Stats */}
              <div className="flex items-center justify-center space-x-8 mt-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{courses.length}</div>
                  <div className="text-sm text-gray-600">Courses</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-indigo-600">15+</div>
                  <div className="text-sm text-gray-600">Teachers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">2.1K+</div>
                  <div className="text-sm text-gray-600">Students</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="pb-8 px-4">
        <div className="container mx-auto">
          <div
            className={`scroll-animate ${animatedElements.has("filters-section") ? "animate" : ""}`}
            id="filters-section"
          >
            <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-6">
              <div className="flex items-center space-x-2">
                <Filter className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-700">Filter by:</span>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <select
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  className="px-4 py-2 rounded-2xl border border-gray-200 bg-white/80 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                >
                  {subjects.map((subject) => (
                    <option key={subject} value={subject}>
                      {subject}
                    </option>
                  ))}
                </select>

                <div className="flex items-center space-x-2 bg-white/80 backdrop-blur-sm rounded-2xl p-1 border border-gray-200">
                  <button
                    onClick={() => setSelectedType("All")}
                    className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                      selectedType === "All" ? "bg-blue-600 text-white shadow-lg" : "text-gray-600 hover:text-blue-600"
                    }`}
                  >
                    All
                  </button>
                  <button
                    onClick={() => setSelectedType("Free")}
                    className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                      selectedType === "Free"
                        ? "bg-green-600 text-white shadow-lg"
                        : "text-gray-600 hover:text-green-600"
                    }`}
                  >
                    Free
                  </button>
                  <button
                    onClick={() => setSelectedType("Paid")}
                    className={`px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                      selectedType === "Paid"
                        ? "bg-amber-600 text-white shadow-lg"
                        : "text-gray-600 hover:text-amber-600"
                    }`}
                  >
                    Paid
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="pb-20 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredCourses.map((course, index) => (
              <div
                key={course.id}
                className={`scroll-animate ${animatedElements.has(`course-${course.id}`) ? "animate" : ""}`}
                id={`course-${course.id}`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <Card className="group cursor-pointer hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4 hover:scale-105 border-0 rounded-3xl overflow-hidden glassmorphism">
                  {/* Course Image */}
                  <div className={`h-48 bg-gradient-to-br ${course.gradient} relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-all duration-500"></div>
                    <Image
                      src={course.image || "/placeholder.svg"}
                      alt={course.title}
                      width={300}
                      height={200}
                      className="w-full h-full object-cover opacity-20 group-hover:opacity-30 transition-opacity duration-500"
                    />

                    {/* Price Badge */}
                    <div className="absolute top-4 right-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-bold ${
                          course.type === "Free" ? "bg-green-500 text-white" : "bg-white text-gray-800"
                        }`}
                      >
                        {course.price}
                      </span>
                    </div>

                    {/* Subject Badge */}
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-white text-sm font-medium">
                        {course.subject}
                      </span>
                    </div>

                    {/* Play Button */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                        <Play className="w-8 h-8 text-white ml-1" />
                      </div>
                    </div>
                  </div>

                  <CardContent className="p-6">
                    <div className="mb-4">
                      <h3 className="font-bold text-lg mb-2 text-gray-800 group-hover:text-blue-600 transition-colors">
                        {course.title}
                      </h3>
                      <p className="text-gray-600 font-medium">by {course.instructor}</p>
                    </div>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <BookOpen className="w-4 h-4" />
                        <span>{course.batchInfo}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <Users className="w-4 h-4" />
                        <span>{course.students} students</span>
                      </div>
                    </div>

                    {/* Rating */}
                    <div className="flex items-center space-x-2 mb-6">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(course.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium text-gray-600">
                        {course.rating} ({course.students} reviews)
                      </span>
                    </div>

                    <Button
                      className={`w-full bg-gradient-to-r ${course.gradient} hover:opacity-90 text-white border-0 transform group-hover:scale-105 transition-all duration-300 rounded-2xl font-semibold shadow-lg py-3`}
                    >
                      {course.type === "Free" ? "Start Learning" : "Enroll Now"}
                    </Button>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">📚</div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">No courses found</h3>
              <p className="text-gray-600">Try adjusting your filters to see more courses.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>

        {/* Background Shapes */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full animate-float"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-white/10 rounded-full animate-float-delayed"></div>

        <div className="container mx-auto relative z-10">
          <div
            className={`text-center text-white scroll-animate ${animatedElements.has("cta-section") ? "animate" : ""}`}
            id="cta-section"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Need help choosing a course?</h2>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Our education consultants are here to guide you towards the perfect learning path for Class 6.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-3xl text-lg font-bold transform hover:scale-105 transition-all duration-300 shadow-xl"
              >
                Talk to a Guide
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-3xl text-lg font-bold transform hover:scale-105 transition-all duration-300"
              >
                Contact Support
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900 text-white py-16 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent mb-6">
                StudyBD
              </div>
              <p className="text-gray-300 mb-6 max-w-md font-medium leading-relaxed">
                Bangladesh's leading online coaching platform for Class 6-10 students. Learn from verified teachers with
                our comprehensive NCTB syllabus-based courses.
              </p>
              <div className="flex space-x-4">
                <Link
                  href="#"
                  className="p-3 bg-blue-600 rounded-2xl hover:bg-blue-700 transition-colors transform hover:scale-110 duration-300"
                >
                  <Facebook className="w-6 h-6" />
                </Link>
                <Link
                  href="#"
                  className="p-3 bg-red-600 rounded-2xl hover:bg-red-700 transition-colors transform hover:scale-110 duration-300"
                >
                  <Youtube className="w-6 h-6" />
                </Link>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-6">Quick Links</h3>
              <ul className="space-y-3 text-gray-300">
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Our Teachers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Success Stories
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-6">Support</h3>
              <ul className="space-y-3 text-gray-300">
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors font-medium">
                    Refund Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center text-gray-300">
            <p className="font-medium">
              &copy; {new Date().getFullYear()} StudyBD. All rights reserved. Made with ❤️ for Bangladeshi students.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
